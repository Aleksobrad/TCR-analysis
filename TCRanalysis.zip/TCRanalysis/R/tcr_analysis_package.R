#' By default, prints summary data tables to output file comparing pre-transplant 
#' baseline to a specified biopsy sample by total number of unique clones and numbers
#'  of mappable alloreactive vs non-alloreactive clones in each. Default analysis 
#'  mode compares alloreactivity rate (by unique clone fraction and cumulative 
#'  frequency) among mappable clones in biopsy vs baseline. This is done by applying 
#'  Fisher’s exact test.Additional analyses modes included but not activated by default are 
#'  turnover, absolute expansion, and clonality.
#' @param cd4: combined data frame of TCR clone counts with columns (in order) representing CD4 pre-transplant unstimulated, CD4 pre-transplant antigen-stimulated, and biopsy
#' @param cd8: combined data frame of TCR clone counts with columns (in order) representing CD8 pre-transplant unstimulated, CD8 pre-transplant antigen-stimulated, and biopsy
#' @param fold: Minimum fold-expansion required from unstimulated to antigen-stimulated repertoire to define a TCR-clone as alloreactive. Set to 5 by default. 
#' @param freq: Minimum frequency required to define a clone as alloreactive if detected in antigen-stimulated but not antigen-unstimulated repertoire (fold-expansion = Infinity in this case). Should represent fold * minimum detection threshold for the sequencing experiment. 
#' @param clonality: When set to TRUE, outputs clonality of entire repertoire and of alloreactive clone subset in pre-transplant baseline and in biopsy. 
#' @param turnover: When set to TRUE, performs statistical test of whether pre-transplant alloreactive clones are more likely to persist to biopsy timepoint than non-alloreactives. This is done by applying Fisher’s exact test
#' @param absoluteexpansion: When set to TRUE, performs statistical test of whether alloreactive clones are more likely to be detected in general in pre-transplant unstimulated sample or in biopsy. This is done by applying Fisher’s exact test 
#' @param ambiguityRatio: ratio of clone frequencies used resolve CD4 vs CD8 sorting error. Clones present in both CD4 and CD8 with a frequency > ambiguityRatio higher in one population will be removed from the other. Clones with frequency difference less than ambiguityRatio will be removed from both. 
#' @param filename: name of file to which output tables will be appended.
#  The function prints output tables to the specified filename
run <- function(cd4, cd8, fold=5, freq=0.00001, clonality=FALSE, turnover=FALSE, absoluteexpansion=FALSE, ambiguityRatio=5, filename="Default") {
  write.table(paste("Number of unique clones in sample (from CD4 table):", length(which(cd4[,3]>0)),  sep="\t"),  quote=F, col.names = F, row.names=F, file=filename, append=T)
  write.table(paste("Number of unique clones in sample (from CD8 table):", length(which(cd8[,3]>0)),  sep="\t"),  quote=F, col.names = F, row.names=F, file=filename, append=T)
  
  cd4 = normalize(cd4)
  cd8 = normalize(cd8)
  
  rows1 = cleanup(cd4[,1], cd8[,1], ratio = ambiguityRatio)
  rows2 = cleanup(cd4[,2], cd8[,2], ratio = ambiguityRatio)
  
  cd4 = exclude(cd4, rows1[,1] | rows2[,1])
  cd8 = exclude(cd8, rows1[,2] | rows2[,2])
  
  cat(paste("\n",colnames(cd4)[3], ": cd4\n"), file=filename, append=T)
  reg(cd4, fold=fold, clonality=clonality, turnover=turnover,absoluteexpansion=absoluteexpansion, freq1=freq, filename=filename)
  cat(paste("\n",colnames(cd8)[3], ": cd8\n"), file=filename, append=T)
  reg(cd8, fold=fold, clonality=clonality, turnover=turnover, absoluteexpansion=absoluteexpansion, freq1=freq,filename=filename)  
}

#' Helper function to identify alloreactive clones, used within the run() function. 
#' @param data: combined data frame of TCR clone counts with columns (in order) representing pre-transplant unstimulated, pre-transplant antigen-stimulated, and biopsy
#' @param fold: Minimum fold-expansion required from unstimulated to antigen-stimulated repertoire to define a TCR-clone as alloreactive. Set to 5 by default. 
#' @param freq: Minimum frequency required to define a clone as alloreactive if detected in antigen-stimulated but not antigen-unstimulated repertoire (fold-expansion = Infinity in this case). Should represent fold * minimum detection threshold for the sequencing experiment. 
#  The function returns in output subset table of clones meeting the alloreactivity criteria.
reactiveClones <- function(data, fold=5, freq=1e-5) {
  rclones = data[data[,2] > freq & data[,2] > data[,1] * fold, ]
  return(rclones)
}

#' Helper function to execute the statistical tests and generate tables in the run() function
#' @param data: combined data frame of TCR clone counts with columns (in order) representing pre-transplant unstimulated, pre-transplant antigen-stimulated, and biopsy
#' @param fold: Minimum fold-expansion required from unstimulated to antigen-stimulated repertoire to define a TCR-clone as alloreactive. Set to 5 by default. 
#' @param freq1: Minimum frequency required to define a clone as alloreactive if detected in antigen-stimulated but not antigen-unstimulated repertoire (fold-expansion = Infinity in this case). Should represent fold * minimum detection threshold for the sequencing experiment. 
#' @param clonality: When set to TRUE, outputs clonality of entire repertoire and of alloreactive clone subset in pre-transplant baseline and in biopsy. 
#' @param turnover: When set to TRUE, performs statistical test of whether pre-transplant alloreactive clones are more likely to persist to biopsy timepoint than non-alloreactives. This is done by applying Fisher’s exact test
#' @param absoluteexpansion: When set to TRUE, performs statistical test of whether alloreactive clones are more likely to be detected in general in pre-transplant unstimulated sample or in biopsy. This is done by applying Fisher’s exact test 
#' @param filename: name of file to which output tables will be appended.
#  The function prints output tables to the specified filename
reg <- function(data, freq1 = 0.00001, freq2 = 0, fold = 5, clonality=FALSE, turnover=FALSE,  absoluteexpansion=FALSE, filename="Default") {
  ## columns in data:
  # unstim, stim, Bx
  
  data = normalize(data)
  
  allPre = data[data[,1] > freq2,]
  allHinBx = data[(data[,1] > freq2 | data[,2] > freq2 ) & data[,3] > freq2 , ]
  
  # all HvG clones
  allHvG = reactiveClones(data, fold=fold, freq= freq1)
  HvGinBx = reactiveClones(allHinBx, fold = fold, freq = freq1)
  
  npre = dim(allPre)[1]
  nHBx = dim(allHinBx)[1]
  
  nhvgpre = dim(allHvG[allHvG[,1]>0, ])[1]
  nhvgpost = dim(HvGinBx)[1]
  
  freqpre = sum(allPre[,1])
  freqBx = sum(allHinBx[,3])
  
  hfreqpre = sum(allHvG[,1])
  hfreqpost = sum(allHvG[,3])
  
  ratio1 = hfreqpre / freqpre
  ratio2 = hfreqpost / freqBx
  # Relative expansion analysis (default): Is a mappable clone (one that can be called alloreactive or nonalloreactive based on preTx MLR), more likely to be alloreactive in postTx than preTx?
  #(i.e.) is the alloreactivity rate higher in postTx than preTx? 
  # allopre, Npre-allopre
  # allopost, Npost-allopost
  write.table("Relative Expansion", quote=F, col.names=F, row.names=F, file=filename, append=T)
  write.table(paste("Samples","preTx_mappable_clones","alloreactive_clones","freq_mapped","freq_alloreactive","allo_cum_freq","allo_clone_fraction", sep="\t"),quote=F,col.names=F,row.names=F, file=filename, append=T)
  write.table(paste("preTx", npre, nhvgpre, round(freqpre, 5), round(hfreqpre, 5), round(ratio1, 5),round(nhvgpre/npre,5),  sep="\t"),  quote=F, col.names = F, row.names=F, file=filename, append=T)
  write.table(paste("postTx",  nHBx, nhvgpost, round(freqBx, 5) , round(hfreqpost,5), round(ratio2, 5),round(nhvgpost/nHBx,5),  sep="\t"),  quote=F, col.names = F, row.names=F, file=filename, append=T)
  
  x = c(nhvgpost, nHBx-nhvgpost)
  y = c(nhvgpre, npre-nhvgpre)
  ft = fisher.test(cbind(x,y))
  write.table(paste("Fisher'sExactTest:\tp-value=", signif(ft$p.value,3), "\tOR=",  signif(ft$estimate, 3),  " (95%CI:",  signif(ft$conf.int[1], 3), "-",signif(ft$conf.int[2], 3), ")", sep="" ),  sep="\t" , quote=F, col.names = F, row.names=F, file=filename, append=T)
  
  # repertoire turnover analysis: are preTx donor-reactive clones more likely to be persist than total preTx clones
  # N1,N0  (detected preTx clones, undetected preTx clones)
  # D1,D0 (donor-reactive clones, undetected donor-reactive clones)
  if(turnover){
    npre=dim(data[data[,1]>0,])[1]
    ndetected=dim(data[data[,1]>0 & data[,3]>0, ])[1]
    nhvgpre=dim(allHvG[allHvG[,1]>0,])[1]
    nhvgdetected=dim(allHvG[allHvG[,1]>0 & allHvG[,3]>0,])[1]
    write.table("Turnover", quote=F, col.names=F, row.names=F, file=filename, append=T)
    write.table(paste("clone sets","detected_in_sample","undetected_in_sample","persistent_clone_fraction", sep="\t"),quote=F,col.names=F,row.names=F, file=filename, append=T)
    write.table(paste("all preTx unstim clones", ndetected, npre-ndetected, ndetected/npre, sep="\t"),  quote=F, col.names = F, row.names=F, file=filename, append=T)
    write.table(paste("HvG clones",  nhvgdetected, nhvgpre-nhvgdetected, nhvgdetected/nhvgpre, sep="\t"),  quote=F, col.names = F, row.names=F, file=filename, append=T)
    x = c(ndetected, npre-ndetected)
    y = c(nhvgdetected,nhvgpre-nhvgdetected) 
    ft = fisher.test(cbind(y,x))
    write.table(paste("Fisher'sExactTest:\tp-value=", signif(ft$p.value,3), "\tOR=",  signif(ft$estimate, 3),  " (95%CI:",  signif(ft$conf.int[1], 3), "-",signif(ft$conf.int[2], 3), ")", sep="" ),  sep="\t" , quote=F, col.names = F, row.names=F, file=filename, append=T)
  }
  
  #absolute expansion analysis: are alloreative clones more likely to be detected in pre or post-transplant sample?
  # pre, N-pre
  # post, N-post   where N is the total number of clones termed alloreactive
  if(absoluteexpansion){
    nhvg=nrow(allHvG)
    write.table("Absolute Expansion", quote=F, col.names=F, row.names=F, file=filename, append=T)
    write.table(paste("clone sets","alloreactive_clones_detected","alloreactive_clones_undetected","detection_rate", sep="\t"),quote=F,col.names=F,row.names=F, file=filename, append=T)
    write.table(paste("preTx", nhvgpre, nhvg-nhvgpre, nhvgpre/nhvg, sep="\t"),  quote=F, col.names = F, row.names=F, file=filename, append=T)
    write.table(paste("postTx",  nhvgpost, nhvg-nhvgpost, nhvgpost/nhvg, sep="\t"),  quote=F, col.names = F, row.names=F, file=filename, append=T)
    x = c(nhvgpre, nhvg-nhvgpre)
    y = c(nhvgpost, nhvg-nhvgpost) 
    ft = fisher.test(cbind(y,x))
    write.table(paste("Fisher'sExactTest:\tp-value=", signif(ft$p.value,3), "\tOR=",  signif(ft$estimate, 3),  " (95%CI:",  signif(ft$conf.int[1], 3), "-",signif(ft$conf.int[2], 3), ")", sep="" ),  sep="\t" , quote=F, col.names = F, row.names=F, file=filename, append=T)
  }
  
  if(clonality==TRUE){
    write.table(paste("clonality\tPre:", cloneCal(allPre[,1]), "\tHvGinPre:", cloneCal(allHvG[allHvG[,1]>0,1]), "\tBx:", cloneCal(allHinBx[,3]), "\tHvGinBx:", cloneCal(HvGinBx[,3])), sep="\t", quote=F, col.names = F, row.names=F, file=filename, append=T)
    write.table(paste("entropy\tPre:", entropyCal(allPre[,1]), "\tHvGinPre:", entropyCal(allHvG[allHvG[,1]>0,1]), "\tBx:", entropyCal(allHinBx[,3]), "\tHvGinBx:", entropyCal(HvGinBx[,3])), sep="\t", quote=F, col.names = F, row.names=F, file=filename, append=T)
    write.table(paste("simpson's index\tPre:", simpsonCal(allPre[,1]), "\tHvGinPre:", simpsonCal(allHvG[allHvG[,1]>0,1]), "\tBx:", simpsonCal(allHinBx[,3]), "\tHvGinBx:", simpsonCal(HvGinBx[,3])), sep="\t", quote=F, col.names = F, row.names=F, file=filename, append=T)
  }
}

#' Function to normalize data frame by column from clone counts to frequencies
#' @param data: clone count matrix where rows are unique TCR clonotypes and columns are samples
#  The function returns in oputput the normalized dataset.
normalize <- function(data) {
  nc = ncol(data)
  for (i in 1:nc) {
    data[,i] = data[,i ] / sum(data[,i])
  }
  return(data)
}

#' Function to compute TCR clonality (noramlized entropy) of a given sample, where 
#' clonality ranges from zero to one, with higher clonality indicating lower reprtoire diversity. 
#' @param array: vector of counts for each unique TCR clonotype in a given sample. 
#  The function returns clonality value of the specified sample
cloneCal <- function(array) {
  x = array[array >0 ] / sum(array)
  #  x = sort(array, decreasing=T)
  l = length(x)
  entropy = sum(x * -1 * log2(x))
  maxentropy = -log2(1/l)
  return(signif(1 - entropy / maxentropy, 2))
}

#' Function to compute TCR entropy of a given sample
#' @param array: vector of counts for each unique TCR clonotype in a given sample. 
#  The function returns entropy value of the specified sample. 
entropyCal<-function(array) {
  x = array[array >0 ] / sum(array)
  entropy = sum(x * -1 * log2(x))
  return(signif(entropy,2))
}

#' Function to compute TCR Simpson's Index of a given sample
#' @param array: vector of counts for each unique TCR clonotype in a given sample. 
#  The function returns Simpson's index value of the specified sample. 
simpsonCal<-function(array) {
  x = array[array >0 ] / sum(array)
  simpson = sum(x * x)
  return(signif(simpson,2))
}

#' Helper function referenced by the run() function. Identifies ambiguous clones which cannot be resolved as either cd4 or cd8
#' @param cd4: combined data frame of TCR clone counts with columns (in order) representing CD4 pre-transplant unstimulated, CD4 pre-transplant antigen-stimulated, and biopsy
#' @param cd8: combined data frame of TCR clone counts with columns (in order) representing CD8 pre-transplant unstimulated, CD8 pre-transplant antigen-stimulated, and biopsy
#' @param ratio: Minimum fold-expansion required from unstimulated to antigen-stimulated repertoire to define a TCR-clone as alloreactive. Set to 5 by default. 
#  The function returns a table of clones to be excluded, with the first column indicating clones to be exlcuded from cd4, and the second column indicating clones to be excluded from cd8
cleanup <- function(cd4, cd8, ratio = 2) {
  ## remove contaminated clones  
  ambi = (cd4 > 0 & cd8 > 0 & cd4 / cd8 > 1/ratio & cd4 / cd8 < ratio) 
  cd4exclude = (cd4 > 0 & cd8 > 0 & cd4 / cd8 <= 1/ratio ) 
  cd8exclude = (cd4 > 0 & cd8 > 0 & cd4 / cd8 >= ratio )  
  return(cbind(ambi | cd4exclude, ambi | cd8exclude))
}

#' Helper function referenced by the run() function. Removes a specified set of rows from input dataframe
#' @param data: combined data frame of TCR clone counts with columns (in order) representing pre-transplant unstimulated, pre-transplant antigen-stimulated, and biopsy
#' @param excluderows: binary vector of length equal to number of rows in data, with F indicating that a given row should be removed from downstream analysis.
#  The function returns in oputput the dataset with excluderows removed. 
exclude <- function(data, excluderows) {
  data = data[excluderows == F, ]
  return(data)
}

#' Function to list all alloreactice clone TCR sequences for custom downstream workflows. Before running, must set 
#' the rownames of input cd4 and cd8 objects as character vectors of the actual TCR sequences for each row 
#' @param cd4: combined data frame of TCR clone counts with columns (in order) representing CD4 pre-transplant unstimulated, CD4 pre-transplant antigen-stimulated, and biopsy
#' @param cd8: combined data frame of TCR clone counts with columns (in order) representing CD8 pre-transplant unstimulated, CD8 pre-transplant antigen-stimulated, and biopsy
#' @param fold: Minimum fold-expansion required from unstimulated to antigen-stimulated repertoire to define a TCR-clone as alloreactive. Set to 5 by default. 
#' @param freq1: Minimum frequency required to define a clone as alloreactive if detected in antigen-stimulated but not antigen-unstimulated repertoire (fold-expansion = Infinity in this case). Should represent fold * minimum detection threshold for the sequencing experiment. 
#' @param ambiguityRatio: Minimum frequency difference required to disambiguate a clone present in both cd4 and cd8 matrices as unambiguously belonging to one or the other. Set to 5 by default. 
#  The function returns a list of all CD4 alloreactive clones in the first slot, and all CD8 alloreactive clones in the second slot
listAlloreactive<-function(cd4,cd8, fold=5, freq1=.00001, ambiguityRatio=5) # rows must be indexed by clone ID
{
  # need only column 1 unstim and column 2 stim
  cd4 = normalize(cd4)
  cd8 = normalize(cd8)
  
  rows1 = cleanup(cd4[,1], cd8[,1], ratio = ambiguityRatio)
  rows2 = cleanup(cd4[,2], cd8[,2], ratio = ambiguityRatio)
  
  cd4 = exclude(cd4, rows1[,1] | rows2[,1])
  cd8 = exclude(cd8, rows1[,2] | rows2[,2])
  
  allHvGcd4 = reactiveClones(normalize(cd4), fold=fold, freq=freq1)
  allHvGcd8 = reactiveClones(normalize(cd8), fold=fold, freq=freq1)
  
  return(list(rownames(allHvGcd4), rownames(allHvGcd8)))
}

#' Function to generate abundance plots from a data frame of TCR frequencies by sample. input data must have been previously normalized to frequencies rather than raw counts.
#' @param data: data frame of normalizxed TCR clone frequencies, with each sample in a unique column
#' @param threshold: minimum clone frequency included in the abundance plot. 0 by default. 
#' @param name: customizeable plot header
#  The function prints an abundance plot of log-counts vs log-frequencies with a linear regression curve fit to each column of the input data. 
abundancePlot<-function(data, threshold=0, name="abundance plot"){
  par(mfrow=c(1,1)) #prepares space for plots, fill by row
  plot(0,type='n', main=name, xlab="log freq", ylab="log abundance", xlim=c(log10(min(data[data>0])),log10(max(data))), ylim=c(0,5))
  color=1
  if(is.null(ncol(data))){
    out=as.data.frame(table(data[data>threshold]))
    points(log10(as.numeric(as.character(out[,1]))), log10(out[,2]),pch=16, col=color)
  }
  else{
    for(index in 1:length(data))
    {
      out=as.data.frame(table(data[data[,index]>threshold,index]))
      points(log10(as.numeric(as.character(out[,1]))), log10(out[,2]),pch=16, col=color)
      color=color+1
    }
    legend("topright", legend=colnames(data), pch=16,col=1:length(data))
  }
}


#' Function to print a stacked barplot of the top N highes-frequency clones in a given sample, coloring the alloreactive clones red. 
#' @param sample: vector of clone frequencies
#' @param rownames: vector of TCR sequences corresponding to the frequencies in sample.
#' @param listAlloreactives: vector of alloreactive clone TCR sequences.
#' @param n: the number of top N clones by frequency to output
#  The function prints a stacked barplot of the top N clones by frequency, colored by alloreactive vs nonalloreactive clone identity
topclones<-function(sample, rownames,listAlloreactives, n=100)
{
  a<-order(sample,decreasing=TRUE)[1:n]
  color<-rep("blue", n)
  color[which(rownames[a] %in% listAlloreactives)]<-"red"
  #barplot(sample[a,3]/sum(sample[,3]), col=color)
  barplot(as.matrix((sample[a]/sum(sample))), col=color, beside=F)
  #barplot(p4[(order(p4[,3],decreasing=T)[1:100]),3]/sum(p4[,3]))
  #return(rownames[a])
}

#' Function to replace clone counts of ambiguous clones or clones mis-sorted into the wrong group with zero counts. 
#' @param data: data frame of TCR clone counts with columns representing distinct sample.
#' @param c1: The column number of the first column to be disambiguated
#' @param c2: The column number of the second column to be disambiguated
#' @param ratio: Minimum frequency ratio required to identify a clone as unambiguously belonging to c1 vs c2 or vice-versa. Set to 2 by default. 
#  The function returns the dataset with counts of ambigous clones replaced with zeros, for customized downstream workflows
resolveambiguous<-function(data,c1,c2,ratio=2){
  normalize(data[,c(c1,c2)])
  c1indices=which(data[,c1]>0 & data[,c2]>0 & data[,c1]>ratio*data[,c2])
  c2indices=which(data[,c1]>0 & data[,c2]>0 & data[,c2]>ratio*data[,c1])
  ambiindices=which(data[,c1]>0 & data[,c2]>0)
  ambiindices=setdiff(setdiff(ambiindices,c1indices),c2indices)
  data[c1indices,c2]=0
  data[c2indices,c1]=0
  data[ambiindices,c(c1,c2)]=0
  return(data)
}


#' Function to perform RPKM or TPM normalization of a gene expression dataset in ensembl or entrez notation.
#' @param input: gene expression dataset
#' @param notation: specify with a string if the dataset in input is in "ensembl" or "entrez" notation
#' @param normalization: specify with a string if you want to perform "RPKM" or "TPM" normalization
#  The function returns in oputput the normalized dataset.
getR20<-function(column,rval=0.2){
  column=column/sum(column)
  column=column[order(column,decreasing = T)]
  num=0
  total=0
  while(total<rval){
    total=total+column[num+1]
    num=num+1
  }
  return(num/length(column))
}



#' For each pairwise combination of columns in data representing distinct TCR-repertoire samples, computes jensen_shannon divergence score. Outputs the resulting table. Analysis is performed subset to the topN clones, with N = -1 including all clones by default
#' @param data: TCR count dataset
#' @param topN: number of topN clones by frequency from each sample to include in pairwise JSD analysis
#  The function returns in oputput the table of pairwise JSD values
jsdReport<-function(data, topN=-1)
{
  out<-matrix(nrow=ncol(data),ncol=ncol(data), dimnames=list(colnames(data), colnames(data)))
  for(i in 1:ncol(data)){
    for(j in 1:ncol(data)){
      if(topN==-1){
        out[i,j]<-jensen_shannon(data[,i], data[,j])
      }
      else{
        a<-order(data[,i],decreasing=TRUE)[1:topN]
        b<-order(data[,j],decreasing=TRUE)[1:topN]
        z<-data[union(a,b),]
        out[i,j]<-jensen_shannon(z[,i],z[,j])
      }
    }
  }
  return(out)
}

#' Function to compute shannon entropy
#' @param p: TCR clone frequency vector
#  The function returns shannon entropy of a given TCR clone frequency vector
shannon.entropy <- function(p)
{
  if (min(p) < 0 || sum(p) <= 0)
    return(NA)
  p.norm <- p[p>0]/sum(p)
  -sum(log2(p.norm)*p.norm)
}

#' Function to compute jensen_shannon divergence of two TCR frequency vectors, ordered by TCR clonotype. 
#' @param p: first vector of TCR frequencies
#' @param q: second vector of TCR frequencies
#  The function returns in oputput the Jensen-Shannon Divergence of the two input vectors.
jensen_shannon <- function(p, q){
  ## JSD = H(0.5 *(p +q)) - 0.5H(p) - 0.5H(q)
  # H(X) = \sum x_i * log2(x_i)
  #  p = p[p >0 & q >0]
  #  q = q[p>0 & q>0]
  p = p / sum(p)
  q = q / sum(q)
  Hj = shannon.entropy(0.5 *(p+q)) 
  Hp = shannon.entropy(p) 
  Hq = shannon.entropy(q)
  
  jsd = Hj - 0.5*(Hp+Hq)
  #	cat(Hj, Hp, Hq, jsd, "\n")
  return(jsd)
}

#' For each pairwise combination of columns in data representing distinct 
#' TCR-repertoire samples, computes jensen_shannon divergence score. 
#' Outputs the resulting table. Repeats this process separately for all clones,
#' the set of the top 5000 clones in each sample with the highest frequency, 
#' the set of the top 1000 clones, the set of the top 500 clones, and the set 
#' of the top 100 clones. 
#' @param data: data frame of clone counts or frequencies where rows are unique TCR sequenced and columns are samples
#  The function returns in output each table of pairwise JSD values. 
jsdThresholded<-function(data)
{
  write.table(jsdReport(data),sep="\t")
  cat("\n")
  write.table(jsdReport(data,topN=5000),sep="\t")
  cat("\n")
  write.table(jsdReport(data,topN=1000),sep="\t")
  cat("\n")
  write.table(jsdReport(data,topN=500),sep="\t")
  cat("\n")
  write.table(jsdReport(data,topN=100), sep="\t")
}
